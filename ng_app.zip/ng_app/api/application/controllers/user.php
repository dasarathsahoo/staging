<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class User extends REST_Controller {

	public function login()
	{

                $postdata = file_get_contents("php://input");
                $request = json_decode($postdata);
                $email = $request->email;
                $password = $request->password;
//		$this->form_validation->set_rules('email', 'email', 'required|valid_email|max_length[256]');
//		$this->form_validation->set_rules('password', 'password', 'required|min_length[8]|max_length[256]');
//		return Validation::validate($this, '', '', function($token, $output)
//		{
//			echo $email = $this->input->post('email');
//			echo $password = $this->input->post('password');
			  $userData = $this->Users->login($email, $password);
//print_r($userData);
			if ( isset($userData->id)) {
				$token = array();
				 $token['id'] = $userData->id ;
				$token = JWT::encode($token, $this->config->item('jwt_key'));
                                $output["success"]= 'success';
                                $output["data"] = array('token'=>$token , "firstName" => $userData->firstName ,"lastName" => $userData->lastName ,"email"=> $userData->email);
			
                                //print_r($output);
                        }
			else
			{
                           
				$output["success"]= 'fail';
			}
                       
			echo json_encode($output);
//		}
//                );
//                
                
	}
	public function login_old()
	{
		$this->form_validation->set_rules('email', 'email', 'required|valid_email|max_length[256]');
		$this->form_validation->set_rules('password', 'password', 'required|min_length[8]|max_length[256]');
		return Validation::validate($this, '', '', function($token, $output)
		{
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$id = $this->Users->login($email, $password);
			if ($id != false) {
				$token = array();
				$token['id'] = $id;
				$output['status'] = true;
				$output['email'] = $email;
				$output['token'] = JWT::encode($token, $this->config->item('jwt_key'));
			}
			else
			{
				$output['errors'] = '{"type": "invalid"}';
			}
			return $output;
		});
	}
	public function register()
	{
		$this->form_validation->set_rules('email', 'email', 'required|valid_email|is_unique[users.email]|max_length[256]');
		$this->form_validation->set_rules('password', 'password', 'required|min_length[8]|max_length[256]');
		return Validation::validate($this, '', '', function($token, $output)
		{
			$email = $this->input->post('email');
			$password = $this->input->post('password');
			$this->Users->register($email, $password);
			$output['status'] = true;
			return $output;
		});
	}

	public function permissions()
	{
		$this->form_validation->set_rules('resource', 'resource', 'required');
		return Validation::validate($this, 'user', 'read', function($token, $output)
		{
			$resource = $this->input->post('resource');
			$acl = new ACL();
			$permissions = $acl->userPermissions($token->id, $resource);
			$output['status'] = true;
			$output['resource'] = $resource;
			$output['permissions'] = $permissions;
			return $output;
		});
	}

}

/* End of file user.php */
/* Location: ./application/controllers/user.php */