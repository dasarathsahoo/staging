<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Role extends REST_Controller {

}

/* End of file role.php */
/* Location: ./application/controllers/role.php */